README: usSEABED data files PAC_EXT.txt, PAC_PRS.txt, PAC_CLC.txt, PAC_CMP.txt,and PAC_FAC.txt

A known problem exists if usSEABED data text files are imported into ESRI GIS products,
converted to shapefiles, and a subset of the data are exported to another shapefile.  Due 
to ESRI's preferred method of setting field parameters by scanning the format of the first few
lines of data, those fields (denoted as "float" fields) with data in the tenths place (0.1) may 
force integers into decimals in an improper manner in the exported shapefile.

This is primarily noted with the null value ("-99").  After export, these values are converted to "-9.9".

The authors believe the shapefiles published in this report will not undergo this transformation if a 
subset of data are exported.  However, users should be very wary of any values of "-9.9" they may 
find in any exported files.

For more information about the known ESRI bug see (as of May 2006)

http://support.esri.com/index.cfm?fa=knowledgebase.techarticles.articleShow&d=24611

